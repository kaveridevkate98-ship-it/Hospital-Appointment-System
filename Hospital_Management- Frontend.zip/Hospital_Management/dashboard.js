let token = localStorage.getItem("token")

fetch("http://localhost:8080/api/doctors",{
headers:{
"Authorization":"Bearer "+token
}
})
.then(res=>res.json())
.then(data=>{
document.getElementById("doctorCount").innerText=data.length
})


fetch("http://localhost:8080/api/appointments/doctor/1",{
headers:{
"Authorization":"Bearer "+token
}
})
.then(res=>res.json())
.then(data=>{
document.getElementById("appointmentCount").innerText=data.length
})


document.getElementById("patientCount").innerText=5