function loadAppointments(){

let token = localStorage.getItem("token")

fetch("http://localhost:8080/api/appointments/all",{
headers:{
"Authorization":"Bearer "+token
}
})

.then(res=>res.json())
.then(data=>{

let container=document.getElementById("appointmentList")
container.innerHTML=""

data.forEach(a=>{

let card=document.createElement("div")
card.className="doctor-card"

let buttons=""

/* show buttons only if appointment is BOOKED */

if(a.status=="BOOKED"){
buttons=`
<button onclick="accept(${a.id})">Accept</button>
<button onclick="reject(${a.id})">Reject</button>
`
}

card.innerHTML=`

<img src="https://cdn-icons-png.flaticon.com/512/3774/3774299.png">

<h3>Doctor: ${a.doctorName}</h3>

<p>Patient: ${a.patientName}</p>

<p>Date: ${a.appointmentDate}</p>

<p>Time: ${a.timeSlot}</p>

<p>Status: ${a.status}</p>

${buttons}

<button onclick="deleteAppointment(${a.id})" class="delete-btn">
Delete
</button>

`

container.appendChild(card)

})

})

}


/* ACCEPT APPOINTMENT */

function accept(id){

let token = localStorage.getItem("token")

fetch("http://localhost:8080/api/appointments/accept/"+id,{
method:"PUT",
headers:{
"Authorization":"Bearer "+token
}
})

.then(res=>res.json())
.then(data=>{
alert("Appointment Accepted")
loadAppointments()
})

}


/* REJECT APPOINTMENT */

function reject(id){

let token = localStorage.getItem("token")

fetch("http://localhost:8080/api/appointments/reject/"+id,{
method:"PUT",
headers:{
"Authorization":"Bearer "+token
}
})

.then(res=>res.json())
.then(data=>{
alert("Appointment Rejected")
loadAppointments()
})

}


/* AUTO LOAD WHEN PAGE OPENS */

loadAppointments()


function deleteAppointment(id){

let token = localStorage.getItem("token")

fetch("http://localhost:8080/api/appointments/delete/"+id,{
method:"DELETE",
headers:{
"Authorization":"Bearer "+token
}
})

.then(res=>res.text())
.then(data=>{
alert("Appointment deleted")
loadAppointments()
})

}