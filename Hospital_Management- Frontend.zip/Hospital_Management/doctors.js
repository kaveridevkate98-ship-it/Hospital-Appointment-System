
function loadDoctors(){

let token = localStorage.getItem("token")

fetch("http://localhost:8080/api/doctors",{
headers:{
"Authorization":"Bearer "+token
}
})

.then(res=>res.json())
.then(data=>{

let container=document.getElementById("doctorList")
container.innerHTML=""

data.forEach(d=>{

let img=""

if(d.gender=="FEMALE"){
img="https://img.freepik.com/premium-vector/medical-doctor-woman-cartoon-icon_24908-22108.jpg"
}else{
img="https://cdn-icons-png.flaticon.com/512/3774/3774299.png"
}

let card=document.createElement("div")
card.className="doctor-card"

card.innerHTML=`

<img src="${img}">

<h4>Doctor ID: ${d.id}</h4>

<h3>${d.name}</h3>

<p>${d.specialization}</p>

<button onclick="deleteDoctor(${d.id})">Delete</button>

`



container.appendChild(card)

})

})

}

function deleteDoctor(id){

let token = localStorage.getItem("token")

fetch("http://localhost:8080/api/doctors/"+id,{
method:"DELETE",
headers:{
"Authorization":"Bearer "+token
}
})
.then(res=>res.text())
.then(data=>{
alert(data)
loadDoctors()
})

}