package com.kaveri.HospitalAppointment.CONTROLLERS;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.kaveri.HospitalAppointment.Service.AppointmentService;
import com.kaveri.HospitalAppointment.entity.Appointment;
import com.kaveri.HospitalAppointment.dto.AppointmentResponse;

@RestController
@RequestMapping("/api/appointments")
@CrossOrigin(origins = "http://localhost:3000")
public class AppointmentController {

    @Autowired
    private AppointmentService service;

    // BOOK APPOINTMENT
    @PostMapping("/book")
    public Appointment book(@RequestBody Appointment appointment){
        return service.book(appointment);
    }

    // DOCTOR VIEW APPOINTMENTS
    @GetMapping("/doctor/{doctorId}")
    public List<Appointment> doctorAppointments(@PathVariable Long doctorId){
        return service.doctorAppointments(doctorId);
    }

    // PATIENT VIEW APPOINTMENTS
    @GetMapping("/patient/{patientId}")
    public List<Appointment> patientAppointments(@PathVariable Long patientId){
        return service.patientAppointments(patientId);
    }

    // GET ALL APPOINTMENTS (WITH DOCTOR NAME + PATIENT NAME)
    @GetMapping("/all")
    public List<AppointmentResponse> getAllAppointments(){
        return service.getAllAppointments();
    }

    // ACCEPT APPOINTMENT
    @PutMapping("/accept/{id}")
    public Appointment accept(@PathVariable Long id){
        return service.acceptAppointment(id);
    }

    // REJECT APPOINTMENT
    @PutMapping("/reject/{id}")
    public Appointment reject(@PathVariable Long id){
        return service.rejectAppointment(id);
    }
    @DeleteMapping("/delete/{id}")
    public String delete(@PathVariable Long id){
        service.deleteAppointment(id);
        return "Appointment deleted successfully";
    }
}