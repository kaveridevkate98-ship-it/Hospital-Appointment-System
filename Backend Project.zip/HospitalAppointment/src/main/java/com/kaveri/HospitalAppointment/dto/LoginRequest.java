package com.kaveri.HospitalAppointment.dto;



public class LoginRequest {
    public String username;
    public String password;
}