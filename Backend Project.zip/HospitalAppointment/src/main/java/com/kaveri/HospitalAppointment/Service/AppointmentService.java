package com.kaveri.HospitalAppointment.Service;


import java.util.List;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kaveri.HospitalAppointment.entity.Appointment;
import com.kaveri.HospitalAppointment.entity.Doctor;
import com.kaveri.HospitalAppointment.entity.User;

import com.kaveri.HospitalAppointment.repository.AppointmentRepository;
import com.kaveri.HospitalAppointment.repository.DoctorRepository;
import com.kaveri.HospitalAppointment.repository.UserRepository;

import com.kaveri.HospitalAppointment.dto.AppointmentResponse;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository repo;

    @Autowired
    private DoctorRepository doctorRepo;

    @Autowired
    private UserRepository userRepo;

    // BOOK APPOINTMENT
    public Appointment book(Appointment appointment){
        appointment.setStatus("BOOKED");
        return repo.save(appointment);
    }

    // DOCTOR VIEW APPOINTMENTS
    public List<Appointment> doctorAppointments(Long doctorId){
        return repo.findByDoctorId(doctorId);
    }

    // PATIENT VIEW APPOINTMENTS
    public List<Appointment> patientAppointments(Long patientId){
        return repo.findByPatientId(patientId);
    }

    // GET ALL APPOINTMENTS WITH DOCTOR + PATIENT NAME
    public List<AppointmentResponse> getAllAppointments(){

        List<Appointment> list = repo.findAll();
        List<AppointmentResponse> response = new ArrayList<>();

        for(Appointment a : list){

            AppointmentResponse r = new AppointmentResponse();

            r.id = a.getId();

            Doctor doctor = doctorRepo.findById(a.getDoctorId()).orElse(null);
            User patient = userRepo.findById(a.getPatientId()).orElse(null);

            r.doctorName = doctor != null ? doctor.getName() : "Unknown";
            r.patientName = patient != null ? patient.getUsername() : "Unknown";

            r.appointmentDate = a.getAppointmentDate();
            r.timeSlot = a.getTimeSlot();
            r.status = a.getStatus();

            response.add(r);
        }

        return response;
    }

    // ACCEPT APPOINTMENT
    public Appointment acceptAppointment(Long id){

        Appointment a = repo.findById(id).get();
        a.setStatus("ACCEPTED");

        return repo.save(a);
    }

    // REJECT APPOINTMENT
    public Appointment rejectAppointment(Long id){

        Appointment a = repo.findById(id).get();
        a.setStatus("REJECTED");

        return repo.save(a);
    }
    
    public void deleteAppointment(Long id){
        repo.deleteById(id);
    }

}