package com.kaveri.HospitalAppointment.CONTROLLERS;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.kaveri.HospitalAppointment.entity.Doctor;
import com.kaveri.HospitalAppointment.repository.DoctorRepository;

@RestController
@RequestMapping("/api/doctors")
@CrossOrigin(origins="*")
public class DoctorController {

    @Autowired
    private DoctorRepository repo;

    // GET ALL DOCTORS
    @GetMapping
    public List<Doctor> getAll(){
        return repo.findAll();
    }

    // ADD DOCTOR
    @PostMapping
    public Doctor add(@RequestBody Doctor doctor){
        return repo.save(doctor);
    }

    // DELETE DOCTOR (RESIGN)
    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id){
        repo.deleteById(id);
        return "Doctor removed successfully";
    }
}