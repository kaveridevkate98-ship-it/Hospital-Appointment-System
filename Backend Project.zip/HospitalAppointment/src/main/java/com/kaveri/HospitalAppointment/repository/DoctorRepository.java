package com.kaveri.HospitalAppointment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kaveri.HospitalAppointment.entity.Doctor;

public interface DoctorRepository extends JpaRepository<Doctor,Long>{}