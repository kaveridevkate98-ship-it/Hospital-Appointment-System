package com.kaveri.HospitalAppointment.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.kaveri.HospitalAppointment.dto.LoginRequest;
import com.kaveri.HospitalAppointment.dto.RegisterRequest;
import com.kaveri.HospitalAppointment.entity.Role;
import com.kaveri.HospitalAppointment.entity.User;
import com.kaveri.HospitalAppointment.repository.UserRepository;
import com.kaveri.HospitalAppointment.security.CustomUserDetailsService;
import com.kaveri.HospitalAppointment.security.JwtUtil;

import org.springframework.security.core.userdetails.UserDetails;

import java.util.HashSet;
import java.util.Set;

@Service
public class UserService {

    @Autowired private UserRepository repo;
    @Autowired private PasswordEncoder encoder;
    @Autowired private JwtUtil jwt;
    @Autowired private CustomUserDetailsService uds;

    // ✅ REGISTER
    public String register(RegisterRequest req){

        if(repo.findByUsername(req.username).isPresent()){
            throw new RuntimeException("Username already exists");
        }

        User user = new User();
        user.setUsername(req.username);
        user.setEmail(req.email);
        user.setPassword(encoder.encode(req.password));

        // ✅ Always assign PATIENT role (secure)
        Set<Role> roles = new HashSet<>();
        roles.add(Role.ROLE_PATIENT);
        user.setRoles(roles);

        repo.save(user);

        return "Registered Successfully";
    }

    // ✅ LOGIN
    public String login(LoginRequest req){

        User user = repo.findByUsername(req.username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if(!encoder.matches(req.password, user.getPassword()))
            throw new RuntimeException("Invalid password");

        UserDetails ud = uds.loadUserByUsername(user.getUsername());

        return jwt.generateToken(ud);
    }
}











































//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//
//import com.kaveri.HospitalAppointment.dto.LoginRequest;
//import com.kaveri.HospitalAppointment.dto.RegisterRequest;
//import com.kaveri.HospitalAppointment.entity.Role;
//import com.kaveri.HospitalAppointment.entity.User;
//import com.kaveri.HospitalAppointment.repository.UserRepository;
//import com.kaveri.HospitalAppointment.security.CustomUserDetailsService;
//import com.kaveri.HospitalAppointment.security.JwtUtil;
//
//import org.springframework.security.core.userdetails.UserDetails;
//
//import java.util.HashSet;
//import java.util.Set;
//
//@Service
//public class UserService {
//
//    @Autowired private UserRepository repo;
//    @Autowired private PasswordEncoder encoder;
//    @Autowired private JwtUtil jwt;
//    @Autowired private CustomUserDetailsService uds;
//
//    public String register(RegisterRequest req){
//
//        if(repo.findByUsername(req.username).isPresent()){
//            throw new RuntimeException("Username already exists");
//        }
//
//        User user = new User();
//        user.setUsername(req.username);
//        user.setEmail(req.email);
//        user.setPassword(encoder.encode(req.password));
//
//        // prevent null & duplicates
//        Set<Role> roles = new HashSet<>();
//        if(req.roles != null && !req.roles.isEmpty()){
//            roles.addAll(req.roles);
//        } else {
//            roles.add(Role.ROLE_PATIENT); // default role
//        }
//
//        user.setRoles(roles);
//
//        repo.save(user);
//
//        return "Registered Successfully";
//    }
//
//    public String login(LoginRequest req){
//
//        User user = repo.findByUsername(req.username)
//                .orElseThrow(() -> new RuntimeException("User not found"));
//
//        if(!encoder.matches(req.password, user.getPassword()))
//            throw new RuntimeException("Invalid password");
//
//        UserDetails ud = uds.loadUserByUsername(user.getUsername());
//
//        return jwt.generateToken(ud);
//    }
//}