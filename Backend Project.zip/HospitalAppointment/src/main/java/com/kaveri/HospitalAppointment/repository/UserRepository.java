package com.kaveri.HospitalAppointment.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kaveri.HospitalAppointment.entity.User;

public interface UserRepository extends JpaRepository<User,Long>{
    Optional<User> findByUsername(String username);
}