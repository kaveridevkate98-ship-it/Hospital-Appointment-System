package com.kaveri.HospitalAppointment.CONTROLLERS;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.kaveri.HospitalAppointment.Service.UserService;
import com.kaveri.HospitalAppointment.dto.LoginRequest;
import com.kaveri.HospitalAppointment.dto.RegisterRequest;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")   // allow all origins for testing
public class AuthController {

    @Autowired
    private UserService service;

    // ✅ REGISTER SINGLE USER
    @PostMapping("/register")
    public String register(@RequestBody RegisterRequest req) {
        return service.register(req);
    }

    // ✅ LOGIN
    @PostMapping("/login")
    public String login(@RequestBody LoginRequest req) {
        return service.login(req);
    }
}